import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import {
  MapPin, Calendar, Tag, Mail, ArrowLeft, CheckCircle2, AlertCircle,
  Send, ImageIcon, ShieldCheck, Loader2, Trash2,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth';
import type { Item } from '@/types';
import { formatDate, getCategoryLabel } from '@/lib/utils';

export default function ItemDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();

  const [item, setItem] = useState<Item | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [message, setMessage] = useState('');
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const [markingReturned, setMarkingReturned] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const isOwner = user?.id === item?.user_id;

  useEffect(() => {
    (async () => {
      const { data, error } = await supabase
        .from('items')
        .select('*')
        .eq('id', id!)
        .maybeSingle();

      if (error || !data) {
        setNotFound(true);
      } else {
        setItem(data);
      }
      setLoading(false);
    })();
  }, [id]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !item) return;
    setSending(true);
    const { error } = await supabase.from('contact_messages').insert({
      item_id: item.id,
      sender_id: user.id,
      message: message.trim(),
    });
    setSending(false);
    if (error) return;
    setSent(true);
    setMessage('');
  };

  const handleMarkReturned = async () => {
    if (!item || !isOwner) return;
    setMarkingReturned(true);
    const { error } = await supabase
      .from('items')
      .update({ status: 'returned' })
      .eq('id', item.id);
    setMarkingReturned(false);
    if (error) return;
    setItem({ ...item, status: 'returned' });
  };

  const handleDelete = async () => {
    if (!item || !isOwner) return;
    if (!confirm('Are you sure you want to delete this item? This cannot be undone.')) return;
    setDeleting(true);
    const { error } = await supabase.from('items').delete().eq('id', item.id);
    setDeleting(false);
    if (error) return;
    navigate('/');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="h-10 w-10 text-royal-600 animate-spin" />
      </div>
    );
  }

  if (notFound || !item) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-20 text-center">
        <AlertCircle className="h-12 w-12 text-gray-300 mx-auto mb-4" />
        <h2 className="text-xl font-bold text-navy-900 mb-2">Item not found</h2>
        <p className="text-gray-500 mb-6">This item may have been removed or the link is incorrect.</p>
        <Link to="/" className="btn-primary">Back to Home</Link>
      </div>
    );
  }

  const isLost = item.type === 'lost';

  return (
    <div>
      {/* Header banner */}
      <div className={`border-b ${isLost ? 'bg-gradient-to-br from-accent-50 to-white' : 'bg-gradient-to-br from-teal-50 to-white'} border-gray-100`}>
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <button onClick={() => navigate(-1)} className="flex items-center gap-1.5 text-sm font-medium text-gray-500 hover:text-navy-900 transition-colors mb-4">
            <ArrowLeft className="h-4 w-4" />
            Back
          </button>
          <div className="flex items-center gap-3 mb-2">
            <span className={`badge ${isLost ? 'badge-lost' : 'badge-found'}`}>
              {isLost ? 'Lost' : 'Found'}
            </span>
            {item.status === 'returned' && (
              <span className="badge badge-returned">
                <CheckCircle2 className="h-3.5 w-3.5" />
                Returned
              </span>
            )}
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-navy-900">{item.title}</h1>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
          {/* Left: Image + Details */}
          <div className="lg:col-span-3 space-y-6">
            {/* Image */}
            <div className="card overflow-hidden">
              <div className="h-72 sm:h-96 bg-gradient-to-br from-navy-50 to-gray-100 flex items-center justify-center">
                {item.image_url ? (
                  <img src={item.image_url} alt={item.title} className="w-full h-full object-cover" />
                ) : (
                  <div className="text-center">
                    <ImageIcon className="h-16 w-16 text-gray-300 mx-auto mb-2" />
                    <p className="text-sm text-gray-400">No image provided</p>
                  </div>
                )}
              </div>
            </div>

            {/* Details */}
            <div className="card p-6">
              <h2 className="text-lg font-bold text-navy-900 mb-4">Item Details</h2>
              <dl className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-4">
                <div className="flex items-start gap-3">
                  <Tag className="h-5 w-5 text-gray-400 mt-0.5" />
                  <div>
                    <dt className="text-xs text-gray-400 font-medium">Category</dt>
                    <dd className="text-sm font-semibold text-navy-900">{getCategoryLabel(item.category)}</dd>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <MapPin className="h-5 w-5 text-gray-400 mt-0.5" />
                  <div>
                    <dt className="text-xs text-gray-400 font-medium">Campus Location</dt>
                    <dd className="text-sm font-semibold text-navy-900">{item.location ?? 'Not specified'}</dd>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Calendar className="h-5 w-5 text-gray-400 mt-0.5" />
                  <div>
                    <dt className="text-xs text-gray-400 font-medium">{isLost ? 'Date Lost' : 'Date Found'}</dt>
                    <dd className="text-sm font-semibold text-navy-900">{formatDate(item.date_lost_or_found)}</dd>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Calendar className="h-5 w-5 text-gray-400 mt-0.5" />
                  <div>
                    <dt className="text-xs text-gray-400 font-medium">Date Reported</dt>
                    <dd className="text-sm font-semibold text-navy-900">{formatDate(item.created_at)}</dd>
                  </div>
                </div>
              </dl>

              {item.description && (
                <div className="mt-6 pt-6 border-t border-gray-100">
                  <h3 className="text-sm font-semibold text-navy-900 mb-2">Description</h3>
                  <p className="text-sm text-gray-600 leading-relaxed whitespace-pre-wrap">{item.description}</p>
                </div>
              )}
            </div>

            {/* Owner actions */}
            {isOwner && (
              <div className="card p-6">
                <h2 className="text-lg font-bold text-navy-900 mb-1">Manage Your Listing</h2>
                <p className="text-sm text-gray-500 mb-4">You reported this item. You can mark it as returned or delete it.</p>
                <div className="flex flex-col sm:flex-row gap-3">
                  {item.status !== 'returned' && (
                    <button onClick={handleMarkReturned} disabled={markingReturned} className="btn-teal">
                      {markingReturned ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle2 className="h-4 w-4" />}
                      Mark as Returned
                    </button>
                  )}
                  <button onClick={handleDelete} disabled={deleting} className="btn-secondary text-red-600 border-red-200 hover:border-red-400 hover:bg-red-50">
                    {deleting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4" />}
                    Delete Listing
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Right: Contact sidebar */}
          <div className="lg:col-span-2">
            <div className="card p-6 sticky top-24">
              <div className="flex items-center gap-2 mb-4">
                <ShieldCheck className="h-5 w-5 text-teal-600" />
                <h2 className="text-lg font-bold text-navy-900">Safe Contact</h2>
              </div>
              <p className="text-sm text-gray-500 mb-6">
                {item.status === 'returned'
                  ? 'This item has been returned to its owner. Thank you to everyone who helped!'
                  : isOwner
                  ? 'Messages from other community members about this item will appear here.'
                  : `Reach out securely about this ${isLost ? 'lost' : 'found'} item. Always verify ownership before handing over any item.`}
              </p>

              {item.status === 'returned' ? (
                <div className="flex items-center gap-2 p-4 rounded-xl bg-teal-50 border border-teal-200">
                  <CheckCircle2 className="h-5 w-5 text-teal-600" />
                  <p className="text-sm text-teal-700 font-medium">Item returned successfully</p>
                </div>
              ) : !user ? (
                <div className="space-y-3">
                  <p className="text-sm text-gray-500">Sign in to contact the person who reported this item.</p>
                  <Link to="/signin" className="btn-primary w-full">
                    <Mail className="h-4 w-4" />
                    Sign In to Contact
                  </Link>
                  <Link to="/signup" className="btn-secondary w-full">Create Account</Link>
                </div>
              ) : isOwner ? (
                <div className="space-y-3">
                  {item.contact_info && (
                    <div className="p-4 rounded-xl bg-gray-50 border border-gray-100">
                      <p className="text-xs text-gray-400 mb-1">Your contact info</p>
                      <p className="text-sm font-semibold text-navy-900">{item.contact_info}</p>
                    </div>
                  )}
                  <p className="text-xs text-gray-400">Other signed-in users can send you messages about this item.</p>
                </div>
              ) : sent ? (
                <div className="flex items-center gap-2 p-4 rounded-xl bg-teal-50 border border-teal-200">
                  <CheckCircle2 className="h-5 w-5 text-teal-600" />
                  <p className="text-sm text-teal-700 font-medium">Message sent! The reporter will be notified.</p>
                </div>
              ) : (
                <form onSubmit={handleSendMessage} className="space-y-3">
                  {item.contact_info && (
                    <div className="p-3 rounded-xl bg-gray-50 border border-gray-100">
                      <p className="text-xs text-gray-400 mb-1">Preferred contact</p>
                      <p className="text-sm font-semibold text-navy-900">{item.contact_info}</p>
                    </div>
                  )}
                  <div>
                    <label className="block text-sm font-semibold text-navy-900 mb-2">Send a message</label>
                    <textarea
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      placeholder="I think this item belongs to me. Here are the details to verify..."
                      rows={4}
                      required
                      className="input-field resize-none"
                    />
                  </div>
                  <button type="submit" disabled={sending} className="btn-primary w-full">
                    {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                    {sending ? 'Sending...' : 'Send Message'}
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
