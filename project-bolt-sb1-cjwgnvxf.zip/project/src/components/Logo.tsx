import { MapPin, Search, Check } from 'lucide-react';

export default function Logo({ className = '', showTagline = false }: { className?: string; showTagline?: boolean }) {
  return (
    <div className={`flex items-center gap-3 ${className}`}>
      <div className="relative">
        <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-royal-500 to-royal-700 shadow-lg shadow-royal-600/30">
          <MapPin className="h-6 w-6 text-white" strokeWidth={2.5} />
          <Search className="absolute h-4 w-4 text-teal-300 top-1.5 left-1.5" strokeWidth={2.5} />
          <Check className="absolute h-2.5 w-2.5 text-teal-400 bottom-2 right-2" strokeWidth={3} />
        </div>
      </div>
      <div>
        <h1 className="text-xl font-bold leading-none text-navy-900">
          Find<span className="text-royal-600">It</span>
        </h1>
        {showTagline && (
          <p className="text-[10px] text-gray-400 mt-1 font-medium tracking-wide">Lost Something? Find It Here.</p>
        )}
      </div>
    </div>
  );
}
