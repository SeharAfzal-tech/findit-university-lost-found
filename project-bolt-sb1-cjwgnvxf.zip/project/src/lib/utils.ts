import { Smartphone, Book, Briefcase, KeyRound, IdCard, Shirt, Gem, Package, type LucideIcon } from 'lucide-react';

export function formatDate(dateString: string | null): string {
  if (!dateString) return 'N/A';
  const date = new Date(dateString);
  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

export function timeAgo(dateString: string): string {
  const date = new Date(dateString);
  const now = new Date();
  const seconds = Math.floor((now.getTime() - date.getTime()) / 1000);
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor(seconds / 60);

  if (days > 0) return `${days}d ago`;
  if (hours > 0) return `${hours}h ago`;
  if (minutes > 0) return `${minutes}m ago`;
  return 'just now';
}

export function getCategoryLabel(value: string): string {
  const labels: Record<string, string> = {
    electronics: 'Electronics',
    books: 'Books & Notes',
    bags: 'Bags & Wallets',
    keys: 'Keys',
    id_cards: 'ID Cards',
    clothing: 'Clothing',
    jewellery: 'Jewellery',
    other: 'Other',
  };
  return labels[value] ?? value;
}

export function getCategoryIcon(category: string): LucideIcon {
  const icons: Record<string, LucideIcon> = {
    electronics: Smartphone,
    books: Book,
    bags: Briefcase,
    keys: KeyRound,
    id_cards: IdCard,
    clothing: Shirt,
    jewellery: Gem,
    other: Package,
  };
  return icons[category] ?? Package;
}
