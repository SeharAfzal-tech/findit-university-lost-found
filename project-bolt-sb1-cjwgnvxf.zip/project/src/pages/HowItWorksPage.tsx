import { Link } from 'react-router-dom';
import {
  FileText, Search, HandHeart, ArrowRight, ShieldCheck,
  Clock, Eye, MessageSquare, CheckCircle2, Package,
} from 'lucide-react';

export default function HowItWorksPage() {
  const steps = [
    {
      icon: FileText,
      number: '01',
      title: 'Report an Item',
      color: 'royal',
      description: 'Submit the item details, description, date, and relevant image to create a listing on FindIt.',
      details: [
        'Choose whether the item is lost or found',
        'Add a clear title, description, and category',
        'Select the campus location where it was lost or found',
        'Upload an image URL for easy identification',
        'Provide safe contact information for others to reach you',
      ],
    },
    {
      icon: Search,
      number: '02',
      title: 'Search and Match',
      color: 'teal',
      description: 'Explore listings and identify items that may match your missing belongings using filters and search.',
      details: [
        'Browse all lost and found items on dedicated pages',
        'Use the search bar to find items by name or keyword',
        'Filter by category: Electronics, Books, Keys, ID Cards, and more',
        'Sort by most recent, oldest, category, or last updated',
        'Check campus locations to narrow your search',
      ],
    },
    {
      icon: HandHeart,
      number: '03',
      title: 'Reconnect Safely',
      color: 'accent',
      description: 'Contact the reporter through the protected process and verify ownership before collecting the item.',
      details: [
        'Sign in to send a secure message to the item reporter',
        'Verify ownership by providing specific identifying details',
        'Arrange a safe pickup location on campus',
        'The reporter marks the item as returned once collected',
        'Help make campus a place where belongings find their way home',
      ],
    },
  ];

  const tips = [
    { icon: Clock, title: 'Report Quickly', text: 'The sooner you report, the better the chances of a match.' },
    { icon: Eye, title: 'Be Specific', text: 'Include color, brand, and unique features in your description.' },
    { icon: MessageSquare, title: 'Stay Safe', text: 'Use the in-app messaging system to communicate safely.' },
    { icon: CheckCircle2, title: 'Verify Ownership', text: 'Always confirm details before handing over any item.' },
  ];

  return (
    <div>
      {/* Header */}
      <div className="bg-gradient-to-br from-royal-600 via-royal-700 to-navy-800 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">How It Works</h1>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto">
            FindIt makes it easy to report, search, and reconnect. Here's the complete process from reporting an item to safely getting it back.
          </p>
        </div>
      </div>

      {/* Steps */}
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-16 space-y-12">
        {steps.map((step, idx) => {
          const Icon = step.icon;
          return (
            <div key={idx} className="grid grid-cols-1 md:grid-cols-3 gap-8 items-start">
              <div className="text-center md:text-left">
                <div className={`relative inline-flex mb-4`}>
                  <div className={`flex h-20 w-20 items-center justify-center rounded-2xl bg-${step.color}-50`}>
                    <Icon className={`h-9 w-9 text-${step.color}-600`} />
                  </div>
                  <span className={`absolute -top-2 -right-2 flex h-7 w-7 items-center justify-center rounded-full bg-${step.color}-600 text-white text-xs font-bold`}>
                    {step.number}
                  </span>
                </div>
                <h2 className="text-2xl font-bold text-navy-900 mb-2">{step.title}</h2>
                <p className="text-sm text-gray-500">{step.description}</p>
              </div>
              <div className="md:col-span-2 card p-6">
                <ul className="space-y-3">
                  {step.details.map((detail, i) => (
                    <li key={i} className="flex items-start gap-3 text-sm text-gray-600">
                      <CheckCircle2 className={`h-5 w-5 text-${step.color}-500 flex-shrink-0 mt-0.5`} />
                      <span>{detail}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          );
        })}
      </div>

      {/* Tips */}
      <section className="bg-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <h2 className="section-title">Tips for Success</h2>
            <p className="section-subtitle">Follow these best practices for the best chance of recovering your belongings</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {tips.map((tip, i) => {
              const Icon = tip.icon;
              return (
                <div key={i} className="card p-6 card-hover text-center">
                  <div className="flex h-12 w-12 mx-auto mb-4 items-center justify-center rounded-xl bg-royal-50">
                    <Icon className="h-6 w-6 text-royal-600" />
                  </div>
                  <h3 className="font-bold text-navy-900 mb-2">{tip.title}</h3>
                  <p className="text-sm text-gray-500">{tip.text}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Safety */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="card p-8 bg-gradient-to-br from-teal-50 to-white border-teal-100">
          <div className="flex flex-col sm:flex-row items-center gap-6">
            <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-teal-100 flex-shrink-0">
              <ShieldCheck className="h-8 w-8 text-teal-600" />
            </div>
            <div className="text-center sm:text-left flex-1">
              <h3 className="text-xl font-bold text-navy-900 mb-2">Safety First</h3>
              <p className="text-sm text-gray-600 max-w-2xl">
                Always meet in a public campus location to exchange items. Verify ownership by asking for specific details only the true owner would know. Never share personal financial information.
              </p>
            </div>
            <Link to="/report" className="btn-teal flex-shrink-0">
              <Package className="h-4 w-4" />
              Report an Item
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
