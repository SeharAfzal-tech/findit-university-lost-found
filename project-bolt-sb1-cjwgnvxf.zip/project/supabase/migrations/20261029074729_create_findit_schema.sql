/*
# FindIt - University Lost & Found Schema

## Overview
Creates the complete database schema for the FindIt lost-and-found management system
for The Shaikh Ayaz University, Shikarpur. The app has sign-in/sign-up, so all data
is owner-scoped using auth.uid().

## New Tables

### 1. `items`
Main table for all lost and found item reports.
- `id` (uuid, PK)
- `type` (text: 'lost' or 'found')
- `title` (text, name of the item)
- `description` (text, detailed description)
- `category` (text: electronics, books, bags, keys, id_cards, clothing, jewellery, other)
- `location` (text, general campus location)
- `date_lost_or_found` (date, when item was lost or found)
- `image_url` (text, URL to item photo)
- `status` (text: 'active', 'returned', default 'active')
- `contact_info` (text, preferred contact method - email/phone)
- `user_id` (uuid, FK auth.users, defaults to auth.uid())
- `created_at` (timestamptz)
- `updated_at` (timestamptz)

### 2. `contact_messages`
Messages sent between users regarding items.
- `id` (uuid, PK)
- `item_id` (uuid, FK items)
- `sender_id` (uuid, FK auth.users)
- `message` (text)
- `created_at` (timestamptz)

## Security
- RLS enabled on all tables.
- `items`: owner-scoped CRUD for authenticated users.
- `contact_messages`: authenticated users can send and read messages related to items
  they reported or messages they sent.
- All tables granted to `authenticated` only.
- Added indexes for common query patterns.
*/

-- Items table
CREATE TABLE IF NOT EXISTS items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type text NOT NULL CHECK (type IN ('lost', 'found')),
  title text NOT NULL,
  description text,
  category text NOT NULL DEFAULT 'other' CHECK (category IN ('electronics', 'books', 'bags', 'keys', 'id_cards', 'clothing', 'jewellery', 'other')),
  location text,
  date_lost_or_found date,
  image_url text,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'returned')),
  contact_info text,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE items ENABLE ROW LEVEL SECURITY;

-- All authenticated users can browse/read items (shared data)
GRANT SELECT ON items TO authenticated;

-- Only owner can insert/update/delete their own items
GRANT INSERT, UPDATE, DELETE ON items TO authenticated;

DROP POLICY IF EXISTS "select_items" ON items;
CREATE POLICY "select_items"
ON items FOR SELECT
TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_own_items" ON items;
CREATE POLICY "insert_own_items"
ON items FOR INSERT
TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_items" ON items;
CREATE POLICY "update_own_items"
ON items FOR UPDATE
TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_items" ON items;
CREATE POLICY "delete_own_items"
ON items FOR DELETE
TO authenticated USING (auth.uid() = user_id);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_items_type ON items (type);
CREATE INDEX IF NOT EXISTS idx_items_category ON items (category);
CREATE INDEX IF NOT EXISTS idx_items_status ON items (status);
CREATE INDEX IF NOT EXISTS idx_items_created_at ON items (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_items_user_id ON items (user_id);

-- Contact messages table
CREATE TABLE IF NOT EXISTS contact_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  item_id uuid NOT NULL REFERENCES items(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  message text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE contact_messages ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT ON contact_messages TO authenticated;

DROP POLICY IF EXISTS "select_contact_messages" ON contact_messages;
CREATE POLICY "select_contact_messages"
ON contact_messages FOR SELECT
TO authenticated USING (
  sender_id = auth.uid()
  OR EXISTS (
    SELECT 1 FROM items
    WHERE items.id = contact_messages.item_id
    AND items.user_id = auth.uid()
  )
);

DROP POLICY IF EXISTS "insert_contact_messages" ON contact_messages;
CREATE POLICY "insert_contact_messages"
ON contact_messages FOR INSERT
TO authenticated WITH CHECK (sender_id = auth.uid());

CREATE INDEX IF NOT EXISTS idx_contact_messages_item_id ON contact_messages (item_id);
CREATE INDEX IF NOT EXISTS idx_contact_messages_sender_id ON contact_messages (sender_id);

-- Auto-update updated_at on items
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS items_updated_at ON items;
CREATE TRIGGER items_updated_at
BEFORE UPDATE ON items
FOR EACH ROW
EXECUTE FUNCTION update_updated_at();
