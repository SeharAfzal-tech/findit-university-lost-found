import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { FileText, Search, HandHeart, ArrowRight, MapPin, Package, CheckCircle2, Activity, TrendingUp } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Item } from '@/types';
import ItemCard from '@/components/ItemCard';
import { CATEGORIES } from '@/types';

export default function HomePage() {
  const [recentItems, setRecentItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({ lost: 0, found: 0, returned: 0, active: 0 });

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from('items')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(8);
      setRecentItems(data ?? []);
      setLoading(false);
    })();

    (async () => {
      const { count: lost } = await supabase.from('items').select('*', { count: 'exact', head: true }).eq('type', 'lost');
      const { count: found } = await supabase.from('items').select('*', { count: 'exact', head: true }).eq('type', 'found');
      const { count: returned } = await supabase.from('items').select('*', { count: 'exact', head: true }).eq('status', 'returned');
      const { count: active } = await supabase.from('items').select('*', { count: 'exact', head: true }).eq('status', 'active');
      setStats({ lost: lost ?? 0, found: found ?? 0, returned: returned ?? 0, active: active ?? 0 });
    })();
  }, []);

  const statCards = [
    { label: 'Lost Items Reported', value: stats.lost, icon: Search, color: 'accent', desc: 'Reported by community' },
    { label: 'Found Items Reported', value: stats.found, icon: Package, color: 'royal', desc: 'Found on campus' },
    { label: 'Items Successfully Returned', value: stats.returned, icon: CheckCircle2, color: 'teal', desc: 'Reunited with owners' },
    { label: 'Active Reports', value: stats.active, icon: Activity, color: 'navy', desc: 'Currently open' },
  ];

  const steps = [
    {
      icon: FileText,
      title: 'Report an Item',
      description: 'Submit the item details, description, date, and relevant image to create a listing.',
      step: '01',
      color: 'royal',
    },
    {
      icon: Search,
      title: 'Search and Match',
      description: 'Explore listings and identify items that may match your missing belongings.',
      step: '02',
      color: 'teal',
    },
    {
      icon: HandHeart,
      title: 'Reconnect Safely',
      description: 'Contact the reporter through the protected process and verify ownership before collecting.',
      step: '03',
      color: 'accent',
    },
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-navy-900 via-navy-800 to-royal-900">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-10 w-72 h-72 bg-royal-500 rounded-full blur-3xl" />
          <div className="absolute bottom-10 right-10 w-96 h-96 bg-teal-500 rounded-full blur-3xl" />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="animate-slide-up">
              <div className="inline-flex items-center gap-2 bg-teal-500/10 border border-teal-400/30 rounded-full px-4 py-1.5 mb-6">
                <MapPin className="h-3.5 w-3.5 text-teal-300" />
                <span className="text-xs font-medium text-teal-200">The Shaikh Ayaz University, Shikarpur</span>
              </div>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white leading-tight tracking-tight">
                Lost Something on Campus?{' '}
                <span className="text-teal-400">Let's Find It.</span>
              </h1>
              <p className="mt-6 text-base sm:text-lg text-gray-300 max-w-xl leading-relaxed">
                FindIt helps The Shaikh Ayaz University community report missing belongings, discover found items, and reconnect people with their lost possessions.
              </p>
              <div className="mt-8 flex flex-col sm:flex-row gap-4">
                <Link to="/report" className="btn-primary bg-royal-500 hover:bg-royal-600">
                  <FileText className="h-5 w-5" />
                  Report Lost Item
                </Link>
                <Link to="/found-items" className="btn-secondary bg-white/10 border-white/20 text-white hover:bg-white/20 hover:border-white/40 hover:text-white">
                  <Search className="h-5 w-5" />
                  Explore Found Items
                </Link>
              </div>
            </div>

            {/* Hero illustration */}
            <div className="relative hidden lg:block animate-fade-in">
              <div className="relative">
                {/* Backpack */}
                <div className="absolute top-0 left-8 w-24 h-24 bg-royal-500 rounded-2xl shadow-2xl flex items-center justify-center rotate-[-8deg] hover:rotate-0 transition-transform duration-500">
                  <Package className="h-10 w-10 text-white" />
                </div>
                {/* Phone with QR */}
                <div className="absolute top-4 right-4 w-28 h-28 bg-navy-700 rounded-3xl shadow-2xl flex items-center justify-center rotate-[6deg] hover:rotate-0 transition-transform duration-500">
                  <div className="grid grid-cols-3 gap-0.5 p-2">
                    {Array.from({ length: 9 }).map((_, i) => (
                      <div key={i} className={`w-3 h-3 rounded-sm ${i % 2 === 0 ? 'bg-teal-400' : 'bg-teal-200/30'}`} />
                    ))}
                  </div>
                </div>
                {/* Books */}
                <div className="absolute top-32 left-0 w-20 h-24 bg-teal-500 rounded-lg shadow-2xl flex items-center justify-center rotate-[3deg] hover:rotate-0 transition-transform duration-500">
                  <span className="text-white text-2xl font-bold">Book</span>
                </div>
                {/* Keys */}
                <div className="absolute top-28 right-12 w-24 h-24 bg-accent-500 rounded-full shadow-2xl flex items-center justify-center rotate-[-12deg] hover:rotate-0 transition-transform duration-500">
                  <KeyIcon />
                </div>
                {/* ID Card */}
                <div className="absolute bottom-8 left-16 w-32 h-20 bg-white rounded-xl shadow-2xl flex items-center justify-center rotate-[4deg] hover:rotate-0 transition-transform duration-500">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 bg-navy-200 rounded-full" />
                    <div className="space-y-1">
                      <div className="w-12 h-1.5 bg-navy-300 rounded" />
                      <div className="w-8 h-1.5 bg-gray-300 rounded" />
                    </div>
                  </div>
                </div>
                {/* Main magnifying glass */}
                <div className="relative w-80 h-80 mx-auto">
                  <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent rounded-full blur-2xl" />
                  <div className="relative flex items-center justify-center h-full">
                    <div className="w-48 h-48 rounded-full border-8 border-white/20 flex items-center justify-center backdrop-blur-sm">
                      <Search className="h-16 w-16 text-white/80" strokeWidth={1.5} />
                    </div>
                    <div className="absolute bottom-8 right-8 w-8 h-24 bg-white/20 rounded-full rotate-[45deg] origin-bottom" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Quick Statistics */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-12 relative z-10">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {statCards.map((stat) => {
            const Icon = stat.icon;
            return (
              <div key={stat.label} className="card p-6">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-3xl font-bold text-navy-900">{stat.value}</p>
                    <p className="text-sm font-medium text-gray-600 mt-1">{stat.label}</p>
                    <p className="text-xs text-gray-400 mt-1">{stat.desc}</p>
                  </div>
                  <div className={`flex h-12 w-12 items-center justify-center rounded-xl bg-${stat.color}-50`}>
                    <Icon className={`h-6 w-6 text-${stat.color}-600`} />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Recent Listings */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between gap-4 mb-8">
          <div>
            <h2 className="section-title !text-left">Recent Listings</h2>
            <p className="text-base text-gray-500 mt-2">Recently reported lost and found items on campus</p>
          </div>
          <Link to="/lost-items" className="btn-secondary">
            View All Items
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="card h-80 animate-pulse">
                <div className="h-48 bg-gray-100 rounded-t-2xl" />
                <div className="p-5 space-y-3">
                  <div className="h-4 bg-gray-100 rounded w-20" />
                  <div className="h-5 bg-gray-100 rounded w-3/4" />
                  <div className="h-3 bg-gray-100 rounded w-full" />
                  <div className="h-3 bg-gray-100 rounded w-2/3" />
                </div>
              </div>
            ))}
          </div>
        ) : recentItems.length === 0 ? (
          <div className="card p-12 text-center">
            <Package className="h-12 w-12 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-navy-900 mb-2">No items reported yet</h3>
            <p className="text-sm text-gray-500 mb-6">Be the first to report a lost or found item on campus.</p>
            <Link to="/report" className="btn-primary">
              <FileText className="h-4 w-4" />
              Report an Item
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {recentItems.map((item) => (
              <ItemCard key={item.id} item={item} />
            ))}
          </div>
        )}
      </section>

      {/* How It Works */}
      <section className="bg-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="section-title">How It Works</h2>
            <p className="section-subtitle">Three simple steps to report, search, and reconnect with lost belongings</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {steps.map((step, idx) => {
              const Icon = step.icon;
              return (
                <div key={idx} className="relative">
                  {idx < steps.length - 1 && (
                    <div className="hidden md:block absolute top-12 left-full w-full h-0.5 bg-gradient-to-r from-gray-200 to-transparent -z-10" />
                  )}
                  <div className="card p-8 text-center h-full hover:shadow-lg transition-shadow">
                    <div className={`relative mx-auto mb-6 flex h-24 w-24 items-center justify-center rounded-full bg-${step.color}-50`}>
                      <Icon className={`h-10 w-10 text-${step.color}-600`} />
                      <span className={`absolute -top-1 -right-1 flex h-8 w-8 items-center justify-center rounded-full bg-${step.color}-600 text-white text-xs font-bold`}>
                        {step.step}
                      </span>
                    </div>
                    <h3 className="text-xl font-bold text-navy-900 mb-3">{step.title}</h3>
                    <p className="text-sm text-gray-500 leading-relaxed">{step.description}</p>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="text-center mt-10">
            <Link to="/how-it-works" className="btn-secondary">
              Learn More
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* Browse by category */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-10">
          <h2 className="section-title">Browse by Category</h2>
          <p className="section-subtitle">Find items organized by type for quick searching</p>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
          {CATEGORIES.map((cat) => (
            <Link
              key={cat.value}
              to={`/lost-items?category=${cat.value}`}
              className="card p-4 text-center card-hover group"
            >
              <p className="text-sm font-semibold text-navy-700 group-hover:text-royal-700 transition-colors">{cat.label}</p>
            </Link>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-16">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-royal-600 via-royal-700 to-navy-800 p-8 sm:p-12 text-center">
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-0 right-0 w-64 h-64 bg-teal-400 rounded-full blur-3xl" />
          </div>
          <div className="relative">
            <TrendingUp className="h-12 w-12 text-teal-400 mx-auto mb-4" />
            <h2 className="text-3xl font-bold text-white mb-4">Ready to Find Your Belongings?</h2>
            <p className="text-gray-300 max-w-2xl mx-auto mb-8">
              Join The Shaikh Ayaz University community in reuniting lost items with their rightful owners. Report an item today and help make campus a better place.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/report" className="btn-teal">
                <FileText className="h-5 w-5" />
                Report an Item
              </Link>
              <Link to="/signup" className="btn-secondary bg-white/10 border-white/20 text-white hover:bg-white/20 hover:border-white/40 hover:text-white">
                <UserPlusIcon />
                Create Account
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

function KeyIcon() {
  return (
    <svg className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
      <circle cx="8" cy="15" r="4" />
      <path d="M10.85 12.15 19 4M18 5l2 2M15 8l2 2" />
    </svg>
  );
}

function UserPlusIcon() {
  return (
    <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
      <circle cx="9" cy="7" r="4" />
      <path d="M3 21v-2a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v2M19 8v6M22 11h-6" />
    </svg>
  );
}
