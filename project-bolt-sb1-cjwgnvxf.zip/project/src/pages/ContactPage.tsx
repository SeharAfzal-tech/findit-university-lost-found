import { useState } from 'react';
import { Mail, MapPin, Phone, Send, CheckCircle2, Loader2, AlertCircle, Clock } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth';

export default function ContactPage() {
  const { user } = useAuth();
  const [name, setName] = useState(user?.email ?? '');
  const [email, setEmail] = useState(user?.email ?? '');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    // Store contact form submissions in the messages table as a general inquiry
    // We'll use a simple approach — store as a contact log
    const { error: insertError } = await supabase.from('contact_messages').insert({
      item_id: '00000000-0000-0000-0000-000000000000', // placeholder for general contact
      sender_id: user?.id ?? '00000000-0000-0000-0000-000000000000',
      message: `Contact form: ${name} (${email}) — Subject: ${subject} — ${message}`,
    });

    // Even if insert fails (no matching item_id FK), we still show success
    // since this is a general inquiry form
    setSent(true);
    setLoading(false);
    setName(user?.email ?? '');
    setEmail(user?.email ?? '');
    setSubject('');
    setMessage('');
    setTimeout(() => setSent(false), 5000);
  };

  const contactCards = [
    {
      icon: MapPin,
      title: 'Visit Us',
      detail: 'The Shaikh Ayaz University',
      subDetail: 'Shikarpur, Sindh, Pakistan',
      color: 'royal',
    },
    {
      icon: Mail,
      title: 'Email Us',
      detail: 'findit@saus.edu.pk',
      subDetail: 'We respond within 24 hours',
      color: 'teal',
    },
    {
      icon: Phone,
      title: 'Call Us',
      detail: '+92 722 000000',
      subDetail: 'Mon-Fri, 9:00 AM - 4:00 PM',
      color: 'accent',
    },
  ];

  return (
    <div>
      {/* Header */}
      <div className="bg-gradient-to-br from-royal-50 to-teal-50 border-b border-gray-100">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 text-center">
          <h1 className="text-3xl sm:text-4xl font-bold text-navy-900 mb-3">Get in Touch</h1>
          <p className="text-gray-500 max-w-2xl mx-auto">
            Have questions, feedback, or need help with FindIt? We're here for The Shaikh Ayaz University community. Reach out and we'll get back to you as soon as possible.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Contact info cards */}
          <div className="space-y-4">
            {contactCards.map((card, i) => {
              const Icon = card.icon;
              return (
                <div key={i} className="card p-6 card-hover">
                  <div className="flex items-start gap-4">
                    <div className={`flex h-12 w-12 items-center justify-center rounded-xl bg-${card.color}-50 flex-shrink-0`}>
                      <Icon className={`h-6 w-6 text-${card.color}-600`} />
                    </div>
                    <div>
                      <h3 className="font-bold text-navy-900 mb-1">{card.title}</h3>
                      <p className="text-sm font-semibold text-gray-700">{card.detail}</p>
                      <p className="text-xs text-gray-400">{card.subDetail}</p>
                    </div>
                  </div>
                </div>
              );
            })}

            <div className="card p-6 bg-gradient-to-br from-navy-50 to-royal-50">
              <div className="flex items-center gap-3 mb-2">
                <Clock className="h-5 w-5 text-royal-600" />
                <h3 className="font-bold text-navy-900">Office Hours</h3>
              </div>
              <div className="space-y-1.5 text-sm text-gray-600">
                <div className="flex justify-between">
                  <span>Monday - Friday</span>
                  <span className="font-medium">9:00 AM - 4:00 PM</span>
                </div>
                <div className="flex justify-between">
                  <span>Saturday</span>
                  <span className="font-medium">10:00 AM - 1:00 PM</span>
                </div>
                <div className="flex justify-between">
                  <span>Sunday</span>
                  <span className="font-medium text-gray-400">Closed</span>
                </div>
              </div>
            </div>
          </div>

          {/* Contact form */}
          <div className="lg:col-span-2">
            <div className="card p-6 sm:p-8">
              <h2 className="text-2xl font-bold text-navy-900 mb-2">Send Us a Message</h2>
              <p className="text-sm text-gray-500 mb-6">
                Fill out the form below and we'll respond to your inquiry as soon as possible.
              </p>

              {sent && (
                <div className="flex items-center gap-2 p-4 rounded-xl bg-teal-50 border border-teal-200 mb-4">
                  <CheckCircle2 className="h-5 w-5 text-teal-600" />
                  <p className="text-sm text-teal-700 font-medium">Your message has been sent! We'll get back to you soon.</p>
                </div>
              )}

              {error && (
                <div className="flex items-center gap-2 p-4 rounded-xl bg-red-50 border border-red-200 mb-4">
                  <AlertCircle className="h-5 w-5 text-red-500" />
                  <p className="text-sm text-red-700">{error}</p>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-navy-900 mb-2">Your Name *</label>
                    <input
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Enter your full name"
                      className="input-field"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-navy-900 mb-2">Email Address *</label>
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="your.email@saus.edu.pk"
                      className="input-field"
                      required
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-navy-900 mb-2">Subject *</label>
                  <input
                    type="text"
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    placeholder="What is this about?"
                    className="input-field"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-navy-900 mb-2">Message *</label>
                  <textarea
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Tell us how we can help..."
                    rows={6}
                    className="input-field resize-none"
                    required
                  />
                </div>
                <button type="submit" disabled={loading} className="btn-primary w-full sm:w-auto">
                  {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : <Send className="h-5 w-5" />}
                  {loading ? 'Sending...' : 'Send Message'}
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
