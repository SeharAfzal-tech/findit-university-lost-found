import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FileText, CheckCircle2, AlertCircle, Loader2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth';
import { CATEGORIES, CAMPUS_LOCATIONS, type ItemType, type ItemCategory } from '@/types';

export default function ReportItemPage() {
  const navigate = useNavigate();
  const { user } = useAuth();

  const [itemType, setItemType] = useState<ItemType>('lost');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<ItemCategory>('electronics');
  const [location, setLocation] = useState('');
  const [date, setDate] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [contactInfo, setContactInfo] = useState(user?.email ?? '');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    if (!title.trim()) {
      setError('Please enter the item name.');
      setLoading(false);
      return;
    }

    const { error: insertError } = await supabase.from('items').insert({
      type: itemType,
      title: title.trim(),
      description: description.trim() || null,
      category,
      location: location || null,
      date_lost_or_found: date || null,
      image_url: imageUrl.trim() || null,
      contact_info: contactInfo.trim() || null,
      status: 'active',
    });

    if (insertError) {
      setError(insertError.message);
      setLoading(false);
      return;
    }

    setSuccess(true);
    setLoading(false);
    setTimeout(() => navigate(itemType === 'lost' ? '/lost-items' : '/found-items'), 1800);
  };

  if (success) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-20">
        <div className="card p-12 text-center">
          <div className="flex h-16 w-16 mx-auto mb-6 items-center justify-center rounded-full bg-teal-100">
            <CheckCircle2 className="h-8 w-8 text-teal-600" />
          </div>
          <h2 className="text-2xl font-bold text-navy-900 mb-2">Item Reported Successfully!</h2>
          <p className="text-gray-500 mb-6">Your {itemType} item has been listed. We'll help the community find and reconnect it.</p>
          <div className="flex justify-center">
            <Loader2 className="h-5 w-5 text-royal-400 animate-spin" />
            <span className="ml-2 text-sm text-gray-400">Redirecting...</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="bg-gradient-to-br from-royal-50 to-white border-b border-gray-100">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <div className="flex items-center gap-3 mb-2">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-royal-100">
              <FileText className="h-5 w-5 text-royal-600" />
            </div>
            <h1 className="text-3xl font-bold text-navy-900">Report an Item</h1>
          </div>
          <p className="text-gray-500 ml-13 max-w-2xl">
            Fill in the details below to report a lost or found item. The more details you provide, the easier it is to find a match.
          </p>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <form onSubmit={handleSubmit} className="card p-6 sm:p-8 space-y-6">
          {/* Type selector */}
          <div>
            <label className="block text-sm font-semibold text-navy-900 mb-3">I want to report a...</label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setItemType('lost')}
                className={`flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all ${
                  itemType === 'lost'
                    ? 'border-accent-500 bg-accent-50 text-accent-700'
                    : 'border-gray-200 text-gray-500 hover:border-gray-300'
                }`}
              >
                <span className="text-lg font-bold">Lost Item</span>
                <span className="text-xs">I lost something on campus</span>
              </button>
              <button
                type="button"
                onClick={() => setItemType('found')}
                className={`flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all ${
                  itemType === 'found'
                    ? 'border-teal-500 bg-teal-50 text-teal-700'
                    : 'border-gray-200 text-gray-500 hover:border-gray-300'
                }`}
              >
                <span className="text-lg font-bold">Found Item</span>
                <span className="text-xs">I found something on campus</span>
              </button>
            </div>
          </div>

          {/* Title */}
          <div>
            <label className="block text-sm font-semibold text-navy-900 mb-2">Item Name *</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Black Samsung Galaxy Phone, Calculus Textbook, Blue Backpack"
              className="input-field"
              required
            />
          </div>

          {/* Description */}
          <div>
            <label className="block text-sm font-semibold text-navy-900 mb-2">Description</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Provide details: color, brand, distinguishing features, contents, etc."
              rows={4}
              className="input-field resize-none"
            />
          </div>

          {/* Category + Location */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-navy-900 mb-2">Category *</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as ItemCategory)}
                className="input-field cursor-pointer"
              >
                {CATEGORIES.map((cat) => (
                  <option key={cat.value} value={cat.value}>{cat.label}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-semibold text-navy-900 mb-2">Campus Location</label>
              <select
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="input-field cursor-pointer"
              >
                <option value="">Select a location</option>
                {CAMPUS_LOCATIONS.map((loc) => (
                  <option key={loc} value={loc}>{loc}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Date + Image */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-navy-900 mb-2">
                {itemType === 'lost' ? 'Date Lost' : 'Date Found'}
              </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="input-field"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-navy-900 mb-2">Image URL (optional)</label>
              <input
                type="url"
                value={imageUrl}
                onChange={(e) => setImageUrl(e.target.value)}
                placeholder="https://..."
                className="input-field"
              />
            </div>
          </div>

          {/* Contact Info */}
          <div>
            <label className="block text-sm font-semibold text-navy-900 mb-2">Contact Information</label>
            <input
              type="text"
              value={contactInfo}
              onChange={(e) => setContactInfo(e.target.value)}
              placeholder="Email or phone number for safe contact"
              className="input-field"
            />
            <p className="text-xs text-gray-400 mt-1.5">This will be visible to signed-in users who want to reach out about this item.</p>
          </div>

          {/* Error */}
          {error && (
            <div className="flex items-start gap-2 p-4 rounded-xl bg-red-50 border border-red-200">
              <AlertCircle className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-red-700">{error}</p>
            </div>
          )}

          {/* Submit */}
          <div className="flex flex-col sm:flex-row gap-3 pt-2">
            <button type="submit" disabled={loading} className="btn-primary flex-1">
              {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : <FileText className="h-5 w-5" />}
              {loading ? 'Submitting...' : `Report ${itemType === 'lost' ? 'Lost' : 'Found'} Item`}
            </button>
            <button type="button" onClick={() => navigate(-1)} className="btn-secondary">
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
