export type ItemType = 'lost' | 'found';

export type ItemCategory =
  | 'electronics'
  | 'books'
  | 'bags'
  | 'keys'
  | 'id_cards'
  | 'clothing'
  | 'jewellery'
  | 'other';

export type ItemStatus = 'active' | 'returned';

export interface Item {
  id: string;
  type: ItemType;
  title: string;
  description: string | null;
  category: ItemCategory;
  location: string | null;
  date_lost_or_found: string | null;
  image_url: string | null;
  status: ItemStatus;
  contact_info: string | null;
  user_id: string;
  created_at: string;
  updated_at: string;
}

export interface ContactMessage {
  id: string;
  item_id: string;
  sender_id: string;
  message: string;
  created_at: string;
}

export interface CategoryOption {
  value: ItemCategory;
  label: string;
}

export const CATEGORIES: CategoryOption[] = [
  { value: 'electronics', label: 'Electronics' },
  { value: 'books', label: 'Books & Notes' },
  { value: 'bags', label: 'Bags & Wallets' },
  { value: 'keys', label: 'Keys' },
  { value: 'id_cards', label: 'ID Cards' },
  { value: 'clothing', label: 'Clothing' },
  { value: 'jewellery', label: 'Jewellery & Accessories' },
  { value: 'other', label: 'Other Items' },
];

export const CAMPUS_LOCATIONS = [
  'Main Campus Building',
  'Central Library',
  'Science Block',
  'Arts Block',
  'Administration Office',
  'Student Common Room',
  'Cafeteria',
  'Sports Ground',
  'Parking Area',
  'Main Gate',
  'Auditorium',
  'Computer Lab',
  'Chemistry Lab',
  'Physics Lab',
  'Garden Area',
  'Other',
];
