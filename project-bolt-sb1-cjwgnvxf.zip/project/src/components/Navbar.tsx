import { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Menu, X, Home, Search, FileText, HelpCircle, Info, Mail, LogIn, UserPlus, LogOut, Package } from 'lucide-react';
import Logo from './Logo';
import { useAuth } from '@/lib/auth';

const navLinks = [
  { name: 'Home', path: '/', icon: Home },
  { name: 'Lost Items', path: '/lost-items', icon: Search },
  { name: 'Found Items', path: '/found-items', icon: Package },
  { name: 'Report an Item', path: '/report', icon: FileText },
  { name: 'How It Works', path: '/how-it-works', icon: HelpCircle },
  { name: 'About', path: '/about', icon: Info },
  { name: 'Contact', path: '/contact', icon: Mail },
];

export default function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { user, signOut } = useAuth();

  useEffect(() => {
    setMobileOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 10);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  return (
    <>
      {/* Announcement bar */}
      <div className="bg-navy-900 text-white text-center py-2 text-xs sm:text-sm font-medium px-4">
        <span className="text-teal-300">&#9733;</span> Made for The Shaikh Ayaz University Community <span className="text-teal-300">&#9733;</span>
      </div>

      <nav className={`sticky top-0 z-50 bg-white/95 backdrop-blur-sm transition-all duration-300 ${scrolled ? 'shadow-md' : 'shadow-sm border-b border-gray-100'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link to="/" className="flex-shrink-0">
              <Logo />
            </Link>

            {/* Desktop nav */}
            <div className="hidden lg:flex items-center gap-1">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                    location.pathname === link.path
                      ? 'text-royal-700 bg-royal-50'
                      : 'text-gray-600 hover:text-navy-900 hover:bg-gray-50'
                  }`}
                >
                  {link.name}
                </Link>
              ))}
            </div>

            {/* Desktop auth buttons */}
            <div className="hidden lg:flex items-center gap-2">
              {user ? (
                <>
                  <span className="text-sm text-gray-500 max-w-[140px] truncate">{user.email}</span>
                  <button onClick={handleSignOut} className="btn-secondary !py-2 !px-4">
                    <LogOut className="h-4 w-4" />
                    Sign Out
                  </button>
                </>
              ) : (
                <>
                  <Link to="/signin" className="btn-secondary !py-2 !px-4">
                    <LogIn className="h-4 w-4" />
                    Sign In
                  </Link>
                  <Link to="/signup" className="btn-primary !py-2 !px-4">
                    <UserPlus className="h-4 w-4" />
                    Create Account
                  </Link>
                </>
              )}
            </div>

            {/* Mobile toggle */}
            <button onClick={() => setMobileOpen(!mobileOpen)} className="lg:hidden p-2 text-navy-700">
              {mobileOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        {mobileOpen && (
          <div className="lg:hidden bg-white border-t border-gray-100 animate-slide-in">
            <div className="px-4 py-3 space-y-1">
              {navLinks.map((link) => {
                const Icon = link.icon;
                return (
                  <Link
                    key={link.path}
                    to={link.path}
                    className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                      location.pathname === link.path
                        ? 'text-royal-700 bg-royal-50'
                        : 'text-gray-600 hover:bg-gray-50'
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                    {link.name}
                  </Link>
                );
              })}
              <div className="pt-3 border-t border-gray-100 space-y-2">
                {user ? (
                  <>
                    <div className="px-3 text-xs text-gray-400 truncate">{user.email}</div>
                    <button onClick={handleSignOut} className="w-full btn-secondary !py-2.5">
                      <LogOut className="h-4 w-4" />
                      Sign Out
                    </button>
                  </>
                ) : (
                  <>
                    <Link to="/signin" className="w-full btn-secondary !py-2.5">
                      <LogIn className="h-4 w-4" />
                      Sign In
                    </Link>
                    <Link to="/signup" className="w-full btn-primary !py-2.5">
                      <UserPlus className="h-4 w-4" />
                      Create Account
                    </Link>
                  </>
                )}
              </div>
            </div>
          </div>
        )}
      </nav>
    </>
  );
}
