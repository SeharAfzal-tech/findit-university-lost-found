import { Link } from 'react-router-dom';
import { Target, Users, ShieldCheck, Heart, MapPin, GraduationCap, ArrowRight, Eye, MessageSquare, CheckCircle2 } from 'lucide-react';
import Logo from '@/components/Logo';

export default function AboutPage() {
  const values = [
    {
      icon: ShieldCheck,
      title: 'Trust & Safety',
      text: 'We prioritize safe interactions with secure messaging and verified community members.',
      color: 'teal',
    },
    {
      icon: Users,
      title: 'Community First',
      text: 'Built for and by The Shaikh Ayaz University community — students, faculty, and staff.',
      color: 'royal',
    },
    {
      icon: Eye,
      title: 'Transparency',
      text: 'All listings are visible to the community, making it easy to find and match items.',
      color: 'accent',
    },
    {
      icon: Heart,
      title: 'Care & Compassion',
      text: 'We understand how stressful losing something can be. FindIt is here to help.',
      color: 'navy',
    },
  ];

  return (
    <div>
      {/* Hero */}
      <div className="bg-gradient-to-br from-navy-900 via-navy-800 to-royal-900 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
          <div className="flex justify-center mb-6">
            <div className="bg-white/10 rounded-2xl p-4 backdrop-blur-sm">
              <Logo />
            </div>
          </div>
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">About FindIt</h1>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto">
            The official lost & found platform for The Shaikh Ayaz University, Shikarpur — helping our community reconnect with what matters.
          </p>
          <div className="inline-flex items-center gap-2 mt-6 bg-teal-500/10 border border-teal-400/30 rounded-full px-4 py-1.5">
            <MapPin className="h-4 w-4 text-teal-300" />
            <span className="text-sm text-teal-200 font-medium">The Shaikh Ayaz University, Shikarpur, Sindh, Pakistan</span>
          </div>
        </div>
      </div>

      {/* Mission */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center">
          <div className="flex justify-center mb-4">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-royal-50">
              <Target className="h-7 w-7 text-royal-600" />
            </div>
          </div>
          <h2 className="section-title">Our Mission</h2>
          <p className="text-lg text-gray-600 mt-4 leading-relaxed max-w-3xl mx-auto">
            FindIt exists to solve a simple but important problem: reuniting the Shaikh Ayaz University community with their lost belongings. Every year, countless items — phones, books, ID cards, keys, and bags — are misplaced across our campus. FindIt provides a centralized, modern platform where students, faculty, and staff can report, search, and safely reconnect with their property.
          </p>
          <p className="text-base text-gray-500 mt-4 max-w-3xl mx-auto">
            We believe that a strong community looks out for one another. By making it easy to report found items and search for lost ones, we're building a campus culture of care and responsibility.
          </p>
        </div>
      </section>

      {/* Values */}
      <section className="bg-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="section-title">Our Values</h2>
            <p className="section-subtitle">The principles that guide everything we build</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((val, i) => {
              const Icon = val.icon;
              return (
                <div key={i} className="card p-6 card-hover text-center">
                  <div className={`flex h-14 w-14 mx-auto mb-4 items-center justify-center rounded-2xl bg-${val.color}-50`}>
                    <Icon className={`h-7 w-7 text-${val.color}-600`} />
                  </div>
                  <h3 className="font-bold text-navy-900 mb-2">{val.title}</h3>
                  <p className="text-sm text-gray-500">{val.text}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Stats band */}
      <section className="bg-gradient-to-r from-royal-600 to-navy-700 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 text-center text-white">
            <div>
              <div className="flex h-12 w-12 mx-auto mb-3 items-center justify-center rounded-xl bg-white/10">
                <GraduationCap className="h-6 w-6 text-teal-300" />
              </div>
              <p className="text-3xl font-bold">1 University</p>
              <p className="text-sm text-gray-300 mt-1">Built for SAUS Shikarpur</p>
            </div>
            <div>
              <div className="flex h-12 w-12 mx-auto mb-3 items-center justify-center rounded-xl bg-white/10">
                <Users className="h-6 w-6 text-teal-300" />
              </div>
              <p className="text-3xl font-bold">8 Categories</p>
              <p className="text-sm text-gray-300 mt-1">All common campus items</p>
            </div>
            <div>
              <div className="flex h-12 w-12 mx-auto mb-3 items-center justify-center rounded-xl bg-white/10">
                <MessageSquare className="h-6 w-6 text-teal-300" />
              </div>
              <p className="text-3xl font-bold">3 Steps</p>
              <p className="text-sm text-gray-300 mt-1">Report, Search, Reconnect</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
        <h2 className="section-title">Join the FindIt Community</h2>
        <p className="section-subtitle mb-8">
          Create an account today and help make The Shaikh Ayaz University a place where belongings find their way home.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link to="/signup" className="btn-primary">
            <CheckCircle2 className="h-5 w-5" />
            Create Account
          </Link>
          <Link to="/how-it-works" className="btn-secondary">
            Learn How It Works
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>
    </div>
  );
}
