import { Link } from 'react-router-dom';
import { Mail, MapPin, Phone, Shield, Heart } from 'lucide-react';
import Logo from './Logo';

export default function Footer() {
  return (
    <footer className="bg-navy-900 text-gray-300 mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="md:col-span-1">
            <div className="mb-4">
              <Logo />
            </div>
            <p className="text-sm text-gray-400 leading-relaxed">
              The official lost & found platform for The Shaikh Ayaz University community.
            </p>
            <p className="text-sm text-teal-400 font-medium mt-2">Lost Something? Find It Here.</p>
          </div>

          {/* Quick links */}
          <div>
            <h3 className="text-white font-semibold text-sm mb-4">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li><Link to="/" className="hover:text-teal-400 transition-colors">Home</Link></li>
              <li><Link to="/lost-items" className="hover:text-teal-400 transition-colors">Lost Items</Link></li>
              <li><Link to="/found-items" className="hover:text-teal-400 transition-colors">Found Items</Link></li>
              <li><Link to="/report" className="hover:text-teal-400 transition-colors">Report an Item</Link></li>
              <li><Link to="/how-it-works" className="hover:text-teal-400 transition-colors">How It Works</Link></li>
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h3 className="text-white font-semibold text-sm mb-4">Resources</h3>
            <ul className="space-y-2 text-sm">
              <li><Link to="/about" className="hover:text-teal-400 transition-colors">About Us</Link></li>
              <li><Link to="/contact" className="hover:text-teal-400 transition-colors">Contact</Link></li>
              <li><Link to="/signin" className="hover:text-teal-400 transition-colors">Sign In</Link></li>
              <li><Link to="/signup" className="hover:text-teal-400 transition-colors">Create Account</Link></li>
            </ul>
          </div>

          {/* Contact info */}
          <div>
            <h3 className="text-white font-semibold text-sm mb-4">Contact</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-2">
                <MapPin className="h-4 w-4 text-teal-400 mt-0.5 flex-shrink-0" />
                <span>The Shaikh Ayaz University, Shikarpur, Sindh, Pakistan</span>
              </li>
              <li className="flex items-start gap-2">
                <Mail className="h-4 w-4 text-teal-400 mt-0.5 flex-shrink-0" />
                <span>findit@saus.edu.pk</span>
              </li>
              <li className="flex items-start gap-2">
                <Phone className="h-4 w-4 text-teal-400 mt-0.5 flex-shrink-0" />
                <span>+92 722 000000</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-10 pt-8 border-t border-navy-700 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-gray-400">
            &copy; {new Date().getFullYear()} FindIt. All rights reserved.
          </p>
          <div className="flex items-center gap-4 text-xs text-gray-400">
            <span className="flex items-center gap-1">
              <Shield className="h-3.5 w-3.5 text-teal-400" />
              Safe &amp; Secure
            </span>
            <span className="flex items-center gap-1">
              Made with <Heart className="h-3.5 w-3.5 text-accent-400" /> for SAUS
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}
