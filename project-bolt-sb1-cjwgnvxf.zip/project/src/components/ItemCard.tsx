import { Link } from 'react-router-dom';
import { MapPin, Calendar, ArrowRight, ImageIcon } from 'lucide-react';
import type { Item } from '@/types';
import { formatDate, getCategoryLabel } from '@/lib/utils';

export default function ItemCard({ item }: { item: Item }) {
  const isLost = item.type === 'lost';

  return (
    <Link to={`/items/${item.id}`} className="group">
      <div className="card card-hover overflow-hidden h-full flex flex-col">
        {/* Image */}
        <div className="relative h-48 bg-gradient-to-br from-navy-50 to-gray-100 overflow-hidden flex items-center justify-center">
          {item.image_url ? (
            <img
              src={item.image_url}
              alt={item.title}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            />
          ) : (
            <ImageIcon className="h-12 w-12 text-gray-300" />
          )}
          <span className={`badge absolute top-3 left-3 ${isLost ? 'badge-lost' : 'badge-found'}`}>
            {isLost ? 'Lost' : 'Found'}
          </span>
          {item.status === 'returned' && (
            <span className="badge badge-returned absolute top-3 right-3">
              Returned
            </span>
          )}
        </div>

        {/* Content */}
        <div className="p-5 flex flex-col flex-1">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-xs font-semibold text-royal-600 bg-royal-50 px-2.5 py-0.5 rounded-full">
              {getCategoryLabel(item.category)}
            </span>
          </div>
          <h3 className="font-bold text-navy-900 text-base mb-2 line-clamp-1 group-hover:text-royal-700 transition-colors">
            {item.title}
          </h3>
          {item.description && (
            <p className="text-sm text-gray-500 line-clamp-2 mb-3">{item.description}</p>
          )}
          <div className="mt-auto space-y-1.5 pt-2">
            {item.location && (
              <div className="flex items-center gap-1.5 text-xs text-gray-500">
                <MapPin className="h-3.5 w-3.5 text-gray-400" />
                <span className="truncate">{item.location}</span>
              </div>
            )}
            <div className="flex items-center gap-1.5 text-xs text-gray-500">
              <Calendar className="h-3.5 w-3.5 text-gray-400" />
              <span>{formatDate(item.created_at)}</span>
            </div>
          </div>
          <div className="mt-4 flex items-center gap-1 text-sm font-semibold text-royal-600 group-hover:text-royal-700 transition-colors">
            View Details
            <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>
      </div>
    </Link>
  );
}
